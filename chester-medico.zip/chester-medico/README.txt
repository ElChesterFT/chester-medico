CHESTER-MEDICO (Protegido)

✔ Requiere chester-api
✔ No funciona si cambian el nombre del recurso
✔ Verifica actualizaciones desde GitHub

CONFIGURACIÓN:
- shared/config.lua
  - ExpectedResourceName = 'chester-medico'
  - versionUrl -> apunta a tu GitHub

GITHUB:
Crea un archivo version.json:
{
  "version": "1.1.0",
  "changelog": "Mejoras médicas y fixes",
  "url": "https://github.com/chesterstudio/chester-medico"
}


--- CHESTER-API / LOCKNAME / UPDATECHECK ---

- Integra notificaciones con chester-api (si está iniciado). Si no, usa ox_lib.
- Si cambian el nombre del resource, NO funcionará y verás en consola:
  "Porfavor contacta con el creador".

- Para mostrar tus últimas actualizaciones de GitHub:
  Edita shared/config.lua -> Config.UpdateCheck (owner/repo y mode).
