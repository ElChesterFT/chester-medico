Config = {}

-- =========================
--  FRAMEWORK
-- =========================
Config.Framework = 'vorp' -- 'vorp' or 'rsg'

-- =========================
--  RESOURCE PROTECTION
-- =========================
Config.ExpectedResourceName = 'chester-medico'

-- =========================
--  CHESTER-API
-- =========================
Config.RequiredApiExport = 'IsAuthorized' -- export expected from chester-api

-- =========================
--  GITHUB UPDATE CHECK
-- =========================
-- Create a public raw file like:
-- https://raw.githubusercontent.com/USER/REPO/main/chester-medico/version.json
Config.GitHub = {
  enabled = true,
  versionUrl = 'https://raw.githubusercontent.com/chesterstudio/chester-medico/main/version.json'
}

-- =========================
--  MEDIC SETTINGS (demo)
-- =========================
Config.MedicJobs = {
  doctor = true,
  medic = true,
}

Config.ReviveItem = 'revive_syringe'


-- =========================
--  CHESTER-API INTEGRATION
-- =========================
Config.ChesterAPI = {
  enabled = true,
  resource = 'chester-api'
}

-- =========================
--  ANTI-RENAME (LOCK NAME)
-- =========================
Config.LockResourceName = 'chester-medico'

-- =========================
--  GITHUB UPDATE CHECK
-- =========================
Config.UpdateCheck = {
  enabled = true,
  -- 'release' usa /releases/latest, 'commit' usa /commits/{ref}
  mode = 'release',
  owner = 'chester-studio',
  repo = 'chester-medico',
  ref = 'main',
  intervalMinutes = 60
}
