Config = {}

-- =========================
-- Framework Switch
-- =========================
-- 'vorp' or 'rsg'
Config.Framework = 'vorp'

-- =========================
-- Jobs allowed
-- =========================
-- The script will allow access if player job is in this list
-- OR if player is whitelisted in the boss menu (saved to DB).
Config.MedicJobs = {
  doctor = true,
  medic = true,
}

-- Jobs that can open Boss Menu (hire/fire/whitelist)
Config.BossJobs = {
  doctorboss = true,
  medicboss = true,
}

-- =========================
-- Death Alert Settings
-- =========================
Config.EnableDeathAlerts = true
Config.AlertCooldownSeconds = 20

-- Who receives alerts (medics only)
Config.AlertRadius = 0.0 -- 0 = all medics, otherwise only medics within meters of the dead player's coords

-- =========================
-- Revive / Heal
-- =========================
Config.ReviveItem = 'med_revive'
Config.ReviveRemoveItem = true
Config.ReviveHealth = 200
Config.HealHealth = 150

-- Animation settings (you can change dict/anim)
Config.Anim = {
  Revive = { dict = 'amb_work@world_human_doctor_kneel@male_a@base', anim = 'base', dur = 9000 },
  Heal   = { dict = 'amb_work@world_human_doctor_kneel@male_a@base', anim = 'base', dur = 6000 },
  Craft  = { dict = 'amb_work@world_human_hammer@male_a@base', anim = 'base', dur = 8000 }
}

-- =========================
-- Hospital / Bring-Injured (admin-like)
-- =========================
-- "Traer herido" teleports target to the nearest Hospital Bed.
Config.HospitalBeds = {
  { coords = vec4(-288.36, 808.34, 119.38, 38.0) },    -- Valentine doctor
  { coords = vec4(2731.52, -1231.64, 49.36, 10.0) },   -- Saint Denis doctor
}

-- =========================
-- Stash / Storage
-- =========================
Config.Storage = {
  Enabled = true,
  Coords = vec4(-289.25, 808.82, 119.38, 130.0),
  Name = 'chester_medico_storage',
  Label = 'Almacén Médico',
  Slots = 60,
  Weight = 200000,
}

-- =========================
-- Crafting Table
-- =========================
Config.Crafting = {
  Enabled = true,
  Coords = vec4(-288.85, 807.30, 119.38, 310.0),
  Label = 'Mesa de Crafteo (Medicina)',
  Recipes = {
    {
      id = 'antidote',
      label = 'Antídoto',
      time = 8000,
      anim = 'Craft',
      ingredients = {
        { item = 'herb_ginseng', count = 2 },
        { item = 'herb_yarrow', count = 2 },
        { item = 'empty_bottle', count = 1 },
      },
      result = { item = 'med_antidote', count = 1 },
    },
    {
      id = 'bandage',
      label = 'Vendas',
      time = 6000,
      anim = 'Craft',
      ingredients = {
        { item = 'cloth', count = 2 },
      },
      result = { item = 'med_bandage', count = 2 },
    },
    {
      id = 'syringe',
      label = 'Jeringa',
      time = 7000,
      anim = 'Craft',
      ingredients = {
        { item = 'metal_scrap', count = 1 },
        { item = 'glass', count = 1 },
      },
      result = { item = 'med_syringe', count = 1 },
    },
    {
      id = 'revive',
      label = 'Jeringa de Reanimación',
      time = 9000,
      anim = 'Craft',
      ingredients = {
        { item = 'med_syringe', count = 1 },
        { item = 'med_antidote', count = 1 },
      },
      result = { item = 'med_revive', count = 1 },
    },
  }
}

-- =========================
-- Billing / Fines
-- =========================
Config.Billing = {
  Enabled = true,
  AllowNegative = true, -- For RSG, negative cash depends on RSGConfig.Money.DontAllowMinus
  MaxFine = 5000,
  DefaultFine = 50,
}

-- =========================
-- Menu / Commands
-- =========================
Config.OpenCommand = 'medic'
Config.BossCommand = 'medboss'

-- =========================
-- Texts (editable)
-- =========================
Config.Text = {
  NoPermission = 'No tienes permiso.',
  NoPlayerNearby = 'No hay jugadores cerca.',
  DeadAlertTitle = '🚑 Alerta Médica',
  DeadAlertDesc = 'Hay un muerto en: %s (ID: %s)',
  SentBill = 'Multa enviada: $%s a ID %s',
  BilledYou = 'Has recibido una multa médica: -$%s',
  Crafting = 'Crafteando: %s',
  NotEnoughItems = 'No tienes los materiales.',
  Revived = 'Reanimación completada.',
  Healed = 'Curación completada.',
  Diagnosed = 'Diagnóstico: %s',
}
