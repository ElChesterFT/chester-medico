-- ======================================================
--  CHESTER_API_NOTIFY_WRAPPER + LOCKNAME (CLIENT)
-- ======================================================
local RES_NAME = GetCurrentResourceName()
local EXPECTED = (Config.LockResourceName or 'chester-medico')

local function PrintCreator()
  print(('^1[%s]^7 Porfavor contacta con el creador.'):format(RES_NAME))
end

if RES_NAME ~= EXPECTED then
  print(('^1[%s]^7 Nombre inválido. Debe llamarse: ^3%s^7'):format(RES_NAME, EXPECTED))
  PrintCreator()
  return
end

local function Notify(data)
  if Config.ChesterAPI and Config.ChesterAPI.enabled and GetResourceState(Config.ChesterAPI.resource) == 'started' then
    local ok = pcall(function()
      exports[Config.ChesterAPI.resource]:Notify(nil, data.type or 'inform', data.description or '')
    end)
    if ok then return end
    ok = pcall(function()
      exports[Config.ChesterAPI.resource]:NotifyRight(nil, data.description or '', data.type or 'inform')
    end)
    if ok then return end
  end
  Notify(data)
end

-- ======================================================

-- =========================
--  CHESTER MEDICO CLIENT (BASE)
-- =========================

RegisterNetEvent('chester_medico:client:deathAlert', function(deadId)
  print('[CHESTER-MEDICO] Alerta de herido ID:', deadId)
end)
