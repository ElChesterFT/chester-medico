local Config = Config
local lib = lib

local function notify(title, desc, type)
  lib.notify({
    title = title or 'chester-medico',
    description = desc or '',
    type = type or 'inform'
  })
end

local function hasMedicAccess()
  return LocalPlayer.state and (LocalPlayer.state.chester_medic == true)
end

local function loadAnim(dict)
  RequestAnimDict(dict)
  while not HasAnimDictLoaded(dict) do
    Wait(10)
  end
end

local function playTimedAnim(dict, anim, dur)
  loadAnim(dict)
  local ped = PlayerPedId()
  TaskPlayAnim(ped, dict, anim, 2.0, 2.0, dur, 1, 0.0, false, false, false)
  Wait(dur)
  ClearPedTasks(ped)
end

local function getClosestPlayer(maxDist)
  local plyPed = PlayerPedId()
  local pcoords = GetEntityCoords(plyPed)
  local closest, closestDist = -1, maxDist or 3.0

  for _, pid in ipairs(GetActivePlayers()) do
    local ped = GetPlayerPed(pid)
    if ped ~= plyPed then
      local dist = #(GetEntityCoords(ped) - pcoords)
      if dist < closestDist then
        closestDist = dist
        closest = GetPlayerServerId(pid)
      end
    end
  end

  return closest, closestDist
end

-- =========================
-- Death reporting (alerts)
-- =========================
local lastAlert = 0
CreateThread(function()
  while true do
    Wait(500)
    if not Config.EnableDeathAlerts then goto continue end
    local ped = PlayerPedId()
    if IsEntityDead(ped) then
      local now = GetGameTimer()
      if now - lastAlert > (Config.AlertCooldownSeconds * 1000) then
        lastAlert = now
        local coords = GetEntityCoords(ped)
        local cause = GetPedCauseOfDeath(ped)
        TriggerServerEvent('chester-medico:server:playerDied', { x = coords.x, y = coords.y, z = coords.z }, cause)
      end
      Wait(1500)
    end
    ::continue::
  end
end)

RegisterNetEvent('chester-medico:client:deathAlert', function(data)
  notify(Config.Text.DeadAlertTitle, data.msg, 'error')

  if data.coords then
    local blip = Citizen.InvokeNative(0x554D9D53F696D002, 1664425300, data.coords.x, data.coords.y, data.coords.z)
    SetBlipSprite(blip, 953018525, true)
    SetBlipScale(blip, 0.9)
    Citizen.InvokeNative(0x9CB1A1623062F402, blip, ('Alerta médica (ID %s)'):format(data.id))
    CreateThread(function()
      Wait(60 * 1000)
      RemoveBlip(blip)
    end)
  end
end)

-- =========================
-- Storage/Crafting interactions
-- =========================
local function openStorage()
  TriggerServerEvent('chester-medico:server:openStorage')
end

local function openCrafting()
  TriggerServerEvent('chester-medico:server:openCrafting')
end

CreateThread(function()
  if Config.Storage.Enabled then
    local c = Config.Storage.Coords
    lib.zones.sphere({
      coords = vec3(c.x, c.y, c.z),
      radius = 2.0,
      inside = function()
        if IsControlJustPressed(0, 0x760A9C6F) then -- G
          if hasMedicAccess() then openStorage() else notify('chester-medico', Config.Text.NoPermission, 'error') end
        end
      end,
      onEnter = function() lib.showTextUI('[G] '..Config.Storage.Label) end,
      onExit = function() lib.hideTextUI() end
    })
  end

  if Config.Crafting.Enabled then
    local c = Config.Crafting.Coords
    lib.zones.sphere({
      coords = vec3(c.x, c.y, c.z),
      radius = 2.0,
      inside = function()
        if IsControlJustPressed(0, 0x760A9C6F) then -- G
          if hasMedicAccess() then openCrafting() else notify('chester-medico', Config.Text.NoPermission, 'error') end
        end
      end,
      onEnter = function() lib.showTextUI('[G] '..Config.Crafting.Label) end,
      onExit = function() lib.hideTextUI() end
    })
  end
end)

-- =========================
-- Main Medic Menu
-- =========================
local function openMedicMenu()
  if not hasMedicAccess() then
    notify('chester-medico', Config.Text.NoPermission, 'error')
    return
  end

  local targetId = getClosestPlayer(3.0)
  local hasTarget = (targetId ~= -1)

  local options = {
    { title = 'Revisar / Diagnóstico', icon = 'stethoscope', onSelect = function()
        if not hasTarget then return notify('chester-medico', Config.Text.NoPlayerNearby, 'error') end
        TriggerServerEvent('chester-medico:server:diagnose', targetId)
      end
    },
    { title = 'Curar', icon = 'kit-medical', onSelect = function()
        if not hasTarget then return notify('chester-medico', Config.Text.NoPlayerNearby, 'error') end
        TriggerServerEvent('chester-medico:server:heal', targetId)
      end
    },
    { title = ('Revivir (Item: %s)'):format(Config.ReviveItem), icon = 'heart-pulse', onSelect = function()
        if not hasTarget then return notify('chester-medico', Config.Text.NoPlayerNearby, 'error') end
        TriggerServerEvent('chester-medico:server:revive', targetId)
      end
    },
    { title = 'Traer herido (permiso tipo admin)', icon = 'truck-medical', onSelect = function()
        if not hasTarget then return notify('chester-medico', Config.Text.NoPlayerNearby, 'error') end
        TriggerServerEvent('chester-medico:server:bringInjured', targetId)
      end
    },
    { title = 'Multar / Cobrar', icon = 'dollar-sign', onSelect = function()
        if not hasTarget then return notify('chester-medico', Config.Text.NoPlayerNearby, 'error') end
        local input = lib.inputDialog('Multa médica', {
          { type = 'number', label = 'Monto', default = Config.Billing.DefaultFine, min = 1, max = Config.Billing.MaxFine }
        })
        if not input then return end
        local amount = tonumber(input[1]) or Config.Billing.DefaultFine
        TriggerServerEvent('chester-medico:server:bill', targetId, amount)
      end
    },
  }

  lib.registerContext({ id = 'chester_medico_main', title = '🚑 Menú Médico', options = options })
  lib.showContext('chester_medico_main')
end

RegisterCommand(Config.OpenCommand, openMedicMenu)

RegisterCommand(Config.BossCommand, function()
  TriggerServerEvent('chester-medico:server:openBossMenu')
end)

RegisterNetEvent('chester-medico:client:doAnim', function(animKey)
  local a = Config.Anim[animKey]
  if not a then return end
  playTimedAnim(a.dict, a.anim, a.dur)
end)

RegisterNetEvent('chester-medico:client:setMedicAccess', function(state)
  LocalPlayer.state:set('chester_medic', state, true)
end)

RegisterNetEvent('chester-medico:client:notify', function(title, desc, type)
  notify(title, desc, type)
end)

RegisterNetEvent('chester-medico:client:teleport', function(vec4coords)
  DoScreenFadeOut(500)
  while not IsScreenFadedOut() do Wait(10) end
  local ped = PlayerPedId()
  SetEntityCoords(ped, vec4coords.x, vec4coords.y, vec4coords.z)
  SetEntityHeading(ped, vec4coords.w or 0.0)
  Wait(150)
  DoScreenFadeIn(600)
end)
