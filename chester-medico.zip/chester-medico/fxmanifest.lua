fx_version 'cerulean'
game 'rdr3'
rdr3_warning 'I acknowledge that this is a prerelease build of RedM, and I am aware my resources *will* become incompatible once RedM ships.'

author 'Chester Studio'
description 'chester-medico (VORP + RSG) - Medics, alerts, revive, diagnosis, billing, stash, crafting, boss hire'
version '1.0.0'

lua54 'yes'

shared_scripts {
  '@ox_lib/init.lua',
  'shared/config.lua'
}

client_scripts {
  'client/main.lua'
}

server_scripts {
  '@oxmysql/lib/MySQL.lua',
  'server/main.lua'
}

dependencies {
  'ox_lib',
  'oxmysql'
}
