fx_version 'cerulean'
game 'rdr3'

author 'chester-studio'
description 'Chester Medico (VORP/RSG) - Requires chester-api'
version '1.1.0'

shared_scripts {
  'shared/config.lua',
}

server_scripts {
  '@oxmysql/lib/MySQL.lua',
  'server/version.lua',
  'server/guard.lua',
  'server/server.lua',
}

client_scripts {
  'client/client.lua',
}

dependencies {
  'oxmysql',
  'chester-api'
}
