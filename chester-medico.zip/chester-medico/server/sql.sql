-- chester-medico (VORP + RSG)
CREATE TABLE IF NOT EXISTS `chester_medic_staff` (
  `identifier` VARCHAR(64) NOT NULL,
  `hired_by` VARCHAR(64) NULL,
  `hired_at` DATETIME NULL,
  PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `chester_medic_cases` (
  `identifier` VARCHAR(64) NOT NULL,
  `last_cause` VARCHAR(64) NULL,
  `last_x` DOUBLE NULL,
  `last_y` DOUBLE NULL,
  `last_z` DOUBLE NULL,
  `updated_at` DATETIME NULL,
  PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `chester_medic_bills` (
  `id` INT NOT NULL AUTO_INCREMENT,
  `issuer_identifier` VARCHAR(64) NOT NULL,
  `target_identifier` VARCHAR(64) NOT NULL,
  `amount` INT NOT NULL,
  `created_at` DATETIME NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_target` (`target_identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- only used if framework can't go negative
CREATE TABLE IF NOT EXISTS `chester_medic_debts` (
  `identifier` VARCHAR(64) NOT NULL,
  `debt` INT NOT NULL DEFAULT 0,
  PRIMARY KEY (`identifier`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
