local Config = Config
local lib = lib

local Framework = {}
local VorpCore, VorpInv, RSGCore = nil, nil, nil

local function svNotify(src, title, desc, type)
  TriggerClientEvent('chester-medico:client:notify', src, title, desc, type)
end

local function getIdentifier(src)
  for _, v in ipairs(GetPlayerIdentifiers(src)) do
    if v:find('license:') then return v end
  end
  return GetPlayerIdentifiers(src)[1]
end

-- =========================
-- Framework adapters
-- =========================
local function initFramework()
  if Config.Framework == 'vorp' then
    VorpCore = exports.vorp_core:GetCore()
    -- Common VORP pattern: exports.vorp_inventory:vorp_inventoryApi()
    VorpInv = exports.vorp_inventory:vorp_inventoryApi()

    Framework.GetJob = function(src)
      local user = VorpCore.getUser(src)
      if not user then return nil end
      local char = user.getUsedCharacter
      return char and char.job or nil
    end

    Framework.GetFullName = function(src)
      local user = VorpCore.getUser(src)
      if not user then return ('ID %s'):format(src) end
      local c = user.getUsedCharacter
      if not c then return ('ID %s'):format(src) end
      return (c.firstname or '') .. ' ' .. (c.lastname or '')
    end

    Framework.GetCash = function(src)
      local user = VorpCore.getUser(src)
      if not user then return 0 end
      local c = user.getUsedCharacter
      return c and (c.money or 0) or 0
    end

    Framework.SetCash = function(src, newAmount)
      local user = VorpCore.getUser(src)
      if not user then return end
      local c = user.getUsedCharacter
      if not c then return end
      local cur = c.money or 0
      local diff = newAmount - cur
      if diff > 0 then c.addCurrency(0, diff) end
      if diff < 0 then c.removeCurrency(0, math.abs(diff)) end
    end

    Framework.RemoveCash = function(src, amount)
      local user = VorpCore.getUser(src)
      if not user then return end
      local c = user.getUsedCharacter
      if not c then return end
      c.removeCurrency(0, amount)
    end

    Framework.HasItem = function(src, item, count)
      local c = VorpInv.getItemCount(src, item)
      return (c or 0) >= (count or 1)
    end
    Framework.RemoveItem = function(src, item, count) VorpInv.subItem(src, item, count or 1) end
    Framework.AddItem = function(src, item, count) VorpInv.addItem(src, item, count or 1) end

  else
    RSGCore = exports['rsg-core']:GetCoreObject()

    Framework.GetJob = function(src)
      local Player = RSGCore.Functions.GetPlayer(src)
      return Player and Player.PlayerData.job and Player.PlayerData.job.name or nil
    end

    Framework.GetFullName = function(src)
      local Player = RSGCore.Functions.GetPlayer(src)
      if not Player then return ('ID %s'):format(src) end
      local c = Player.PlayerData.charinfo or {}
      return (c.firstname or '') .. ' ' .. (c.lastname or '')
    end

    Framework.GetCash = function(src)
      local Player = RSGCore.Functions.GetPlayer(src)
      return Player and Player.PlayerData.money and Player.PlayerData.money.cash or 0
    end

    Framework.SetCash = function(src, newAmount)
      local Player = RSGCore.Functions.GetPlayer(src)
      if not Player then return end
      Player.Functions.SetMoney('cash', newAmount, 'chester-medico')
    end

    Framework.RemoveCash = function(src, amount)
      local Player = RSGCore.Functions.GetPlayer(src)
      if not Player then return end
      Player.Functions.RemoveMoney('cash', amount, 'chester-medico')
    end

    Framework.HasItem = function(src, item, count)
      local Player = RSGCore.Functions.GetPlayer(src)
      if not Player then return false end
      local it = Player.Functions.GetItemByName(item)
      return it and (it.amount or 0) >= (count or 1)
    end

    Framework.RemoveItem = function(src, item, count)
      local Player = RSGCore.Functions.GetPlayer(src)
      if not Player then return end
      Player.Functions.RemoveItem(item, count or 1)
      TriggerClientEvent('rsg-inventory:client:ItemBox', src, item, "remove")
    end

    Framework.AddItem = function(src, item, count)
      local Player = RSGCore.Functions.GetPlayer(src)
      if not Player then return end
      Player.Functions.AddItem(item, count or 1)
      TriggerClientEvent('rsg-inventory:client:ItemBox', src, item, "add")
    end
  end
end

-- =========================
-- Permissions (job OR whitelist)
-- =========================
local function isWhitelisted(src)
  local id = getIdentifier(src)
  local row = MySQL.single.await('SELECT 1 FROM chester_medic_staff WHERE identifier = ? LIMIT 1', { id })
  return row ~= nil
end

local function isMedic(src)
  local job = Framework.GetJob(src)
  if job and Config.MedicJobs[job] then return true end
  return isWhitelisted(src)
end

local function isBoss(src)
  local job = Framework.GetJob(src)
  return (job and Config.BossJobs[job]) or false
end

local function setMedicState(src)
  TriggerClientEvent('chester-medico:client:setMedicAccess', src, isMedic(src))
end

AddEventHandler('playerJoining', function()
  local src = source
  SetTimeout(1500, function()
    if GetPlayerName(src) then setMedicState(src) end
  end)
end)

CreateThread(function()
  initFramework()
  Wait(1000)
  for _, src in ipairs(GetPlayers()) do
    setMedicState(tonumber(src))
  end

  if Config.Storage.Enabled and Config.Framework == 'rsg' then
    exports['rsg-inventory']:CreateStash(Config.Storage.Name, Config.Storage.Label, Config.Storage.Slots, Config.Storage.Weight)
  end
end)

-- =========================
-- Death alerts + diagnosis memory
-- =========================
local function formatLocation(coords) return ('%.1f, %.1f'):format(coords.x or 0.0, coords.y or 0.0) end

local function diagnoseFromCause(causeHash)
  local c = tonumber(causeHash) or 0
  local map = {
    [GetHashKey('WEAPON_THROWN_DYNAMITE')] = 'Explosión / dinamita',
    [GetHashKey('WEAPON_DYNAMITE')] = 'Explosión / dinamita',
    [GetHashKey('WEAPON_REVOLVER_CATTLEMAN')] = 'Herida de bala',
    [GetHashKey('WEAPON_REPEATER_CARBINE')] = 'Herida de bala',
    [GetHashKey('WEAPON_RIFLE_BOLTACTION')] = 'Herida de bala',
    [GetHashKey('WEAPON_MELEE_KNIFE')] = 'Corte / apuñalado',
    [GetHashKey('WEAPON_MELEE_MACHETE')] = 'Corte profundo',
    [GetHashKey('WEAPON_BOW')] = 'Flecha / perforación',
  }
  return map[c] or 'Trauma / causa desconocida'
end

RegisterNetEvent('chester-medico:server:playerDied', function(coords, cause)
  if not Config.EnableDeathAlerts then return end
  local deadSrc = source

  local payload = {
    coords = coords,
    id = deadSrc,
    msg = Config.Text.DeadAlertDesc:format(formatLocation(coords), deadSrc)
  }

  for _, pid in ipairs(GetPlayers()) do
    local p = tonumber(pid)
    if isMedic(p) then
      if Config.AlertRadius and Config.AlertRadius > 0.0 then
        local pcoords = GetEntityCoords(GetPlayerPed(p))
        local dist = #(vector3(coords.x, coords.y, coords.z) - pcoords)
        if dist <= Config.AlertRadius then
          TriggerClientEvent('chester-medico:client:deathAlert', p, payload)
        end
      else
        TriggerClientEvent('chester-medico:client:deathAlert', p, payload)
      end
    end
  end

  MySQL.update('INSERT INTO chester_medic_cases (identifier, last_cause, last_x, last_y, last_z, updated_at) VALUES (?, ?, ?, ?, ?, NOW()) ON DUPLICATE KEY UPDATE last_cause=VALUES(last_cause), last_x=VALUES(last_x), last_y=VALUES(last_y), last_z=VALUES(last_z), updated_at=NOW()',
    { getIdentifier(deadSrc), tostring(cause or 0), coords.x, coords.y, coords.z })
end)

-- =========================
-- Storage / Crafting
-- =========================
RegisterNetEvent('chester-medico:server:openStorage', function()
  local src = source
  if not isMedic(src) then return svNotify(src, 'chester-medico', Config.Text.NoPermission, 'error') end
  if not Config.Storage.Enabled then return end

  if Config.Framework == 'rsg' then
    exports['rsg-inventory']:OpenStash(src, Config.Storage.Name)
  else
    TriggerClientEvent('vorp_inventory:OpenCustomInventory', src, Config.Storage.Name, Config.Storage.Label)
  end
end)

RegisterNetEvent('chester-medico:server:openCrafting', function()
  local src = source
  if not isMedic(src) then return svNotify(src, 'chester-medico', Config.Text.NoPermission, 'error') end
  if not Config.Crafting.Enabled then return end

  local opts = {}
  for _, r in ipairs(Config.Crafting.Recipes) do
    opts[#opts+1] = {
      title = r.label,
      description = ('Tiempo: %ss'):format(math.floor((r.time or 0) / 1000)),
      icon = 'flask',
      event = 'chester-medico:server:craft',
      args = { id = r.id }
    }
  end

  TriggerClientEvent('ox_lib:showContext', src, { id='chester_medico_craft', title=Config.Crafting.Label, options=opts })
end)

RegisterNetEvent('chester-medico:server:craft', function(data)
  local src = source
  if not isMedic(src) then return end

  local recipe
  for _, r in ipairs(Config.Crafting.Recipes) do
    if r.id == (data and data.id) then recipe = r break end
  end
  if not recipe then return end

  for _, ing in ipairs(recipe.ingredients or {}) do
    if not Framework.HasItem(src, ing.item, ing.count) then
      return svNotify(src, 'chester-medico', Config.Text.NotEnoughItems, 'error')
    end
  end

  TriggerClientEvent('chester-medico:client:doAnim', src, recipe.anim or 'Craft')
  svNotify(src, 'chester-medico', Config.Text.Crafting:format(recipe.label), 'inform')

  SetTimeout(recipe.time or 5000, function()
    for _, ing in ipairs(recipe.ingredients or {}) do
      Framework.RemoveItem(src, ing.item, ing.count)
    end
    Framework.AddItem(src, recipe.result.item, recipe.result.count or 1)
    svNotify(src, 'chester-medico', ('Listo: %s'):format(recipe.label), 'success')
  end)
end)

-- =========================
-- Diagnose / Heal / Revive
-- =========================
RegisterNetEvent('chester-medico:server:diagnose', function(target)
  local src = source
  target = tonumber(target)
  if not target then return end
  if not isMedic(src) then return end

  local row = MySQL.single.await('SELECT last_cause FROM chester_medic_cases WHERE identifier = ? LIMIT 1', { getIdentifier(target) })
  local text = diagnoseFromCause(row and row.last_cause or 0)
  svNotify(src, 'chester-medico', Config.Text.Diagnosed:format(text), 'inform')
end)

RegisterNetEvent('chester-medico:server:heal', function(target)
  local src = source
  target = tonumber(target)
  if not target then return end
  if not isMedic(src) then return end

  TriggerClientEvent('chester-medico:client:doAnim', src, 'Heal')
  SetTimeout((Config.Anim.Heal and Config.Anim.Heal.dur) or 6000, function()
    local tped = GetPlayerPed(target)
    if tped and tped ~= 0 then
      local h = GetEntityHealth(tped)
      SetEntityHealth(tped, math.max(h, Config.HealHealth))
    end
    svNotify(src, 'chester-medico', Config.Text.Healed, 'success')
  end)
end)

RegisterNetEvent('chester-medico:server:revive', function(target)
  local src = source
  target = tonumber(target)
  if not target then return end
  if not isMedic(src) then return end

  if Config.ReviveItem and Config.ReviveItem ~= '' and not Framework.HasItem(src, Config.ReviveItem, 1) then
    return svNotify(src, 'chester-medico', ('Necesitas: %s'):format(Config.ReviveItem), 'error')
  end

  TriggerClientEvent('chester-medico:client:doAnim', src, 'Revive')
  SetTimeout((Config.Anim.Revive and Config.Anim.Revive.dur) or 9000, function()
    if Config.ReviveRemoveItem and Config.ReviveItem and Config.ReviveItem ~= '' then
      Framework.RemoveItem(src, Config.ReviveItem, 1)
    end

    local tped = GetPlayerPed(target)
    if tped and tped ~= 0 then
      if IsEntityDead(tped) then ResurrectPed(tped) end
      ClearPedTasksImmediately(tped)
      SetEntityHealth(tped, Config.ReviveHealth)
    end
    svNotify(src, 'chester-medico', Config.Text.Revived, 'success')
  end)
end)

-- =========================
-- Bring Injured (teleport to nearest bed)
-- =========================
RegisterNetEvent('chester-medico:server:bringInjured', function(target)
  local src = source
  target = tonumber(target)
  if not target then return end
  if not isMedic(src) then return end

  local mped = GetPlayerPed(src)
  local mcoords = GetEntityCoords(mped)
  local best, bestDist = nil, 999999.0
  for _, b in ipairs(Config.HospitalBeds) do
    local v = b.coords
    local dist = #(vector3(v.x, v.y, v.z) - mcoords)
    if dist < bestDist then bestDist, best = dist, v end
  end
  if not best then return end

  TriggerClientEvent('chester-medico:client:teleport', target, best)
  svNotify(src, 'chester-medico', ('Herido traído a la clínica (ID %s).'):format(target), 'success')
end)

-- =========================
-- Billing / Fines
-- =========================
RegisterNetEvent('chester-medico:server:bill', function(target, amount)
  local src = source
  target = tonumber(target)
  amount = math.floor(tonumber(amount) or Config.Billing.DefaultFine)
  if not target then return end
  if not isMedic(src) then return end
  if amount < 1 or amount > Config.Billing.MaxFine then return end

  local before = Framework.GetCash(target)
  local after = before - amount

  if Config.Framework == 'rsg' and Config.Billing.AllowNegative then
    -- RSG can prevent minus cash via RSGConfig.Money.DontAllowMinus
    Framework.SetCash(target, after)
  elseif after >= 0 then
    Framework.RemoveCash(target, amount)
  else
    Framework.SetCash(target, 0)
    MySQL.update('INSERT INTO chester_medic_debts (identifier, debt) VALUES (?, ?) ON DUPLICATE KEY UPDATE debt = debt + VALUES(debt)',
      { getIdentifier(target), math.abs(after) })
  end

  MySQL.insert('INSERT INTO chester_medic_bills (issuer_identifier, target_identifier, amount, created_at) VALUES (?, ?, ?, NOW())',
    { getIdentifier(src), getIdentifier(target), amount })

  svNotify(src, 'chester-medico', Config.Text.SentBill:format(amount, target), 'success')
  svNotify(target, 'chester-medico', Config.Text.BilledYou:format(amount), 'error')
end)

-- =========================
-- Boss Menu (whitelist hire/fire)
-- =========================
RegisterNetEvent('chester-medico:server:openBossMenu', function()
  local src = source
  if not isBoss(src) then return svNotify(src, 'chester-medico', Config.Text.NoPermission, 'error') end

  local options = {
    { title='Contratar (whitelist) jugador cercano', icon='user-plus', event='chester-medico:server:bossHireNear' },
    { title='Despedir (quitar whitelist) jugador cercano', icon='user-minus', event='chester-medico:server:bossFireNear' },
    { title='Ver lista de whitelist', icon='list', event='chester-medico:server:bossList' },
  }

  TriggerClientEvent('ox_lib:showContext', src, { id='chester_medico_boss', title='🏥 Jefe Médico', options=options })
end)

local function getClosestServerPlayer(src, maxDist)
  local sp = GetPlayerPed(src)
  local sc = GetEntityCoords(sp)
  local best, bestDist = nil, maxDist or 3.0
  for _, pid in ipairs(GetPlayers()) do
    local p = tonumber(pid)
    if p ~= src then
      local ped = GetPlayerPed(p)
      local dist = #(GetEntityCoords(ped) - sc)
      if dist < bestDist then bestDist, best = dist, p end
    end
  end
  return best
end

RegisterNetEvent('chester-medico:server:bossHireNear', function()
  local src = source
  if not isBoss(src) then return end
  local t = getClosestServerPlayer(src, 3.0)
  if not t then return svNotify(src, 'chester-medico', Config.Text.NoPlayerNearby, 'error') end

  MySQL.update('INSERT IGNORE INTO chester_medic_staff (identifier, hired_by, hired_at) VALUES (?, ?, NOW())',
    { getIdentifier(t), getIdentifier(src) })
  svNotify(src, 'chester-medico', ('Contratado: %s (ID %s)'):format(Framework.GetFullName(t), t), 'success')
  setMedicState(t)
end)

RegisterNetEvent('chester-medico:server:bossFireNear', function()
  local src = source
  if not isBoss(src) then return end
  local t = getClosestServerPlayer(src, 3.0)
  if not t then return svNotify(src, 'chester-medico', Config.Text.NoPlayerNearby, 'error') end

  MySQL.update('DELETE FROM chester_medic_staff WHERE identifier = ?', { getIdentifier(t) })
  svNotify(src, 'chester-medico', ('Despedido: %s (ID %s)'):format(Framework.GetFullName(t), t), 'success')
  setMedicState(t)
end)

RegisterNetEvent('chester-medico:server:bossList', function()
  local src = source
  if not isBoss(src) then return end
  local rows = MySQL.query.await('SELECT identifier, hired_at FROM chester_medic_staff ORDER BY hired_at DESC LIMIT 50', {})
  local opts = {}
  for _, r in ipairs(rows or {}) do
    opts[#opts+1] = { title=r.identifier, description=('Desde: %s'):format(r.hired_at or 'N/A'), icon='id-card' }
  end
  if #opts == 0 then opts[1] = { title='Sin empleados', icon='circle-xmark' } end
  TriggerClientEvent('ox_lib:showContext', src, { id='chester_medico_boss_list', title='Empleados (whitelist)', options=opts })
end)
