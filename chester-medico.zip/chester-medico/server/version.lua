-- =========================
--  VERSION CHECK (GITHUB)
-- =========================
local CURRENT_VERSION = GetResourceMetadata(GetCurrentResourceName(), 'version', 0)

if not Config.GitHub.enabled then return end

CreateThread(function()
  PerformHttpRequest(Config.GitHub.versionUrl, function(code, data)
    if code ~= 200 or not data then
      print('^3[CHESTER-MEDICO]^7 No se pudo comprobar actualizaciones.')
      return
    end

    local ok, json = pcall(function() return json.decode(data) end)
    if not ok or not json.version then
      print('^3[CHESTER-MEDICO]^7 Formato de versión inválido.')
      return
    end

    if json.version ~= CURRENT_VERSION then
      print('^1[CHESTER-MEDICO]^7')
      print('^1ACTUALIZACIÓN DISPONIBLE^7')
      print('Actual: '..CURRENT_VERSION..' | Última: '..json.version)
      if json.changelog then
        print('Cambios: '..json.changelog)
      end
      print('Descarga: '..(json.url or 'GitHub'))
    else
      print('^2[CHESTER-MEDICO]^7 Script actualizado (v'..CURRENT_VERSION..')')
    end
  end, 'GET')
end)
