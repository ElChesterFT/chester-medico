-- ======================================================
--  LOCKNAME_CHECK + CHESTER-API + UPDATE CHECKER
-- ======================================================
local RES_NAME = GetCurrentResourceName()
local EXPECTED = (Config.LockResourceName or 'chester-medico')

local function PrintCreator()
  print(('^1[%s]^7 Porfavor contacta con el creador.'):format(RES_NAME))
end

if RES_NAME ~= EXPECTED then
  print(('^1[%s]^7 Nombre inválido. Debe llamarse: ^3%s^7'):format(RES_NAME, EXPECTED))
  PrintCreator()
  CreateThread(function()
    Wait(1000)
    StopResource(RES_NAME)
  end)
  return
end

local function ChesterNotify(src, data)
  if Config.ChesterAPI and Config.ChesterAPI.enabled and GetResourceState(Config.ChesterAPI.resource) == 'started' then
    local ok = pcall(function()
      exports[Config.ChesterAPI.resource]:Notify(src, data.type or 'inform', data.description or '')
    end)
    if ok then return end

    ok = pcall(function()
      exports[Config.ChesterAPI.resource]:NotifyRight(src, data.description or '', data.type or 'inform')
    end)
    if ok then return end
  end
  ChesterNotify(src, data)
end

local function StartUpdateChecker()
  if not (Config.UpdateCheck and Config.UpdateCheck.enabled) then return end
  local owner = tostring(Config.UpdateCheck.owner or '')
  local repo  = tostring(Config.UpdateCheck.repo or '')
  if owner == '' or repo == '' or owner == 'CHANGE_ME' or repo == 'CHANGE_ME' then
    print(('^3[%s]^7 UpdateCheck: configura Config.UpdateCheck.owner/repo para ver tus últimas actualizaciones de GitHub.'):format(RES_NAME))
    return
  end

  local mode = (Config.UpdateCheck.mode or 'release'):lower()
  local url
  if mode == 'commit' then
    local ref = tostring(Config.UpdateCheck.ref or 'main')
    url = ('https://api.github.com/repos/%s/%s/commits/%s'):format(owner, repo, ref)
  else
    url = ('https://api.github.com/repos/%s/%s/releases/latest'):format(owner, repo)
  end

  local localVersion = GetResourceMetadata(RES_NAME, 'version', 0) or '0.0.0'
  local interval = tonumber(Config.UpdateCheck.intervalMinutes) or 60
  interval = math.max(10, interval)

  local function checkOnce()
    PerformHttpRequest(url, function(code, body, headers)
      if code ~= 200 or not body then
        print(('^1[%s]^7 UpdateCheck falló (HTTP %s).'):format(RES_NAME, tostring(code)))
        return
      end

      local ok, data = pcall(function() return json.decode(body) end)
      if not ok or not data then
        print(('^1[%s]^7 UpdateCheck: respuesta inválida de GitHub.'):format(RES_NAME))
        return
      end

      if mode == 'commit' then
        local remote = data.sha and tostring(data.sha):sub(1, 7) or 'N/A'
        print(('^2[%s]^7 GitHub commit: ^3%s^7 | Local version: ^3%s^7'):format(RES_NAME, remote, localVersion))
      else
        local remote = data.tag_name and tostring(data.tag_name) or nil
        if remote then
          if remote ~= localVersion then
            print(('^3[%s]^7 Hay una actualización disponible: ^2%s^7 (GitHub) vs ^1%s^7 (local).'):format(RES_NAME, remote, localVersion))
          else
            print(('^2[%s]^7 Estás actualizado: ^3%s^7'):format(RES_NAME, localVersion))
          end
        else
          print(('^3[%s]^7 UpdateCheck: no se encontró tag_name en releases/latest.'):format(RES_NAME))
        end
      end
    end, 'GET', '', { ['Accept'] = 'application/vnd.github+json' })
  end

  CreateThread(function()
    Wait(4000)
    checkOnce()
    while true do
      Wait(interval * 60000)
      checkOnce()
    end
  end)
end

StartUpdateChecker()

-- ======================================================

-- =========================
--  CHESTER MEDICO SERVER (BASE)
-- =========================

RegisterNetEvent('chester_medico:server:notifyDeath', function(deadId)
  local src = source
  for _, pid in ipairs(GetPlayers()) do
    -- Demo notify to medics
    TriggerClientEvent('chester_medico:client:deathAlert', pid, deadId)
  end
end)
