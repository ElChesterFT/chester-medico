-- =========================
--  RESOURCE GUARD
-- =========================
local resName = GetCurrentResourceName()

if resName ~= Config.ExpectedResourceName then
  print('^1[CHESTER-MEDICO]^7')
  print('^1ERROR:^7 El recurso fue renombrado ('..resName..')')
  print('^1Por favor contacta con el creador.^7')
  StopResource(resName)
  return
end

-- =========================
--  CHESTER-API CHECK
-- =========================
CreateThread(function()
  Wait(500)
  if not exports['chester-api'] or not exports['chester-api'][Config.RequiredApiExport] then
    print('^1[CHESTER-MEDICO]^7')
    print('^1ERROR:^7 chester-api no encontrado o export inválido.')
    print('^1Por favor contacta con el creador.^7')
    StopResource(resName)
    return
  end

  local ok = exports['chester-api'][Config.RequiredApiExport]()
  if not ok then
    print('^1[CHESTER-MEDICO]^7')
    print('^1ERROR:^7 chester-api rechazó la autorización.')
    print('^1Por favor contacta con el creador.^7')
    StopResource(resName)
    return
  end
end)
