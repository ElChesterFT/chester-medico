# chester-medico (VORP + RSG)

Sistema médico premium:
- Alertas cuando alguien muere (notifica a medics)
- Menú moderno (ox_lib): Diagnóstico, Curar, Revivir (con item), Traer herido, Multar
- Almacén (stash) por vector4
- Mesa de crafteo (antídotos, vendas, jeringas, revive)
- Boss menu (contratar/despedir por whitelist)

## Dependencias
- oxmysql
- ox_lib
- VORP Core + vorp_inventory  **o**  RSG Core + rsg-inventory

## Instalación
1) Importa `server/sql.sql` en tu base de datos.
2) Coloca `chester-medico` en tus resources.
3) En tu `server.cfg`:
   - ensure oxmysql
   - ensure ox_lib
   - ensure tu framework/inventario
   - ensure chester-medico
4) Edita `shared/config.lua`:
   - `Config.Framework = 'vorp'` o `'rsg'`
   - jobs, coords de almacén/crafteo/camas

## Comandos
- `/medic` abre el menú médico
- `/medboss` abre el menú de jefe (solo BossJobs)

## Ítems (agrega a tu items DB)
- med_antidote
- med_bandage
- med_syringe
- med_revive

## Nota sobre dinero negativo (RSG)
En rsg-core existe `RSGConfig.Money.DontAllowMinus = { 'cash', ... }` y `MinusLimit` que controlan si se permite dinero en negativo.
Si quieres que las multas dejen el cash en negativo, debes permitirlo en tu configuración de rsg-core.
